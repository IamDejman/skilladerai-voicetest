import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { analyzeSpeech } from "./services/openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.status(200).json({ status: 'ok', message: 'Server is running' });
  });

  // Assessment endpoint
  app.post('/api/assessment', async (req, res) => {
    try {
      const { audio, prompt } = req.body;

      if (!audio || !prompt) {
        return res.status(400).json({ message: 'Audio and prompt data are required' });
      }

      // Process audio with OpenAI
      const result = await analyzeSpeech(audio, prompt);
      
      res.status(200).json(result);
    } catch (error) {
      console.error('Error processing assessment:', error);
      res.status(500).json({ 
        message: 'Error processing speech assessment',
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
