import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";

interface AudioRecorderProps {
  onRecordingComplete: (audioBlob: Blob) => void;
  promptText?: string;
}

const AudioRecorder = ({ onRecordingComplete, promptText = "The quick brown fox jumps over the lazy dog." }: AudioRecorderProps) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      audioChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorderRef.current.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        onRecordingComplete(audioBlob);
        
        // Stop all tracks to release the microphone
        stream.getTracks().forEach(track => track.stop());
        
        if (timerRef.current) {
          clearInterval(timerRef.current);
          timerRef.current = null;
        }
        setRecordingTime(0);
      };

      mediaRecorderRef.current.start();
      setIsRecording(true);
      
      // Start timer
      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);

    } catch (error) {
      console.error("Error accessing microphone:", error);
      alert("Unable to access your microphone. Please check your browser permissions.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-neutral">
      <div className="bg-primary px-6 py-4 flex items-center">
        <i className="ri-mic-fill text-white text-xl mr-2"></i>
        <h3 className="font-nunito font-bold text-white text-lg">Skilladder Assessment</h3>
      </div>
      <div className="p-6 bg-white">
        <div className="bg-neutral rounded-xl p-6 mb-6">
          <p className="font-nunito font-bold mb-2">Please read this sentence aloud:</p>
          <p className="text-lg font-opensans">{promptText}</p>
        </div>
        <div className="flex justify-center items-center mb-6">
          <div className={`audio-wave ${isRecording ? '' : 'inactive'}`}>
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="audio-wave-bar"></div>
            ))}
          </div>
        </div>
        {isRecording && (
          <div className="text-center mb-4 text-lg font-nunito">
            Recording: <span className="text-primary font-bold">{formatTime(recordingTime)}</span>
          </div>
        )}
        <Button
          onClick={isRecording ? stopRecording : startRecording}
          className={`w-full py-6 ${
            isRecording
              ? 'bg-[#F44336] hover:bg-[#D32F2F]'
              : 'bg-secondary hover:bg-[#1976D2]'
          } text-white font-nunito font-bold rounded-full transition-colors flex items-center justify-center h-auto`}
        >
          <i className={`${isRecording ? 'ri-stop-line' : 'ri-mic-line'} mr-2 text-xl`}></i>
          {isRecording ? 'Stop Recording' : 'Start Speaking'}
        </Button>
        <p className="text-center text-sm mt-4 text-text opacity-70">
          {isRecording
            ? 'Click the button to stop recording when you are finished'
            : 'Click the button and start speaking to begin the assessment'}
        </p>
      </div>
    </div>
  );
};

export default AudioRecorder;
