import { Link } from "wouter";

const Footer = () => {
  return (
    <footer className="bg-[#333333] text-white py-12 px-4 sm:px-6 lg:px-8 mt-0">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-1">
            <div className="flex items-center mb-4">
              <i className="ri-stack-line text-primary text-2xl mr-2"></i>
              <span className="font-nunito font-bold text-xl">Skilladder AI</span>
            </div>
            <p className="font-opensans text-white/70 mb-4">
              AI-powered English speaking assessment and improvement platform
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white/70 hover:text-primary transition-colors">
                <i className="ri-twitter-fill text-xl"></i>
              </a>
              <a href="#" className="text-white/70 hover:text-primary transition-colors">
                <i className="ri-facebook-fill text-xl"></i>
              </a>
              <a href="#" className="text-white/70 hover:text-primary transition-colors">
                <i className="ri-linkedin-fill text-xl"></i>
              </a>
              <a href="#" className="text-white/70 hover:text-primary transition-colors">
                <i className="ri-instagram-fill text-xl"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-nunito font-bold text-lg mb-4">Product</h3>
            <ul className="space-y-2">
              <li><a href="#features" className="font-opensans text-white/70 hover:text-primary transition-colors">Features</a></li>
              <li><a href="#pricing" className="font-opensans text-white/70 hover:text-primary transition-colors">Pricing</a></li>
              <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">For Teams</a></li>
              <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">For Education</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-nunito font-bold text-lg mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">Blog</a></li>
              <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">Learning Center</a></li>
              <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">Pronunciation Guide</a></li>
              <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">CEFR Framework</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-nunito font-bold text-lg mb-4">Company</h3>
            <ul className="space-y-2">
              <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">About Us</a></li>
              <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">Careers</a></li>
              <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">Contact</a></li>
              <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">Privacy Policy</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/20 mt-12 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="font-opensans text-white/50 text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} Skilladder AI. All rights reserved.
          </p>
          <div className="flex space-x-4">
            <a href="#" className="font-opensans text-white/50 hover:text-primary transition-colors text-sm">Terms of Service</a>
            <a href="#" className="font-opensans text-white/50 hover:text-primary transition-colors text-sm">Privacy Policy</a>
            <a href="#" className="font-opensans text-white/50 hover:text-primary transition-colors text-sm">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
