import { useEffect } from "react";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const Home = () => {
  // Handle smooth scrolling for anchor links
  useEffect(() => {
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a[href^="#"]');
      if (!anchor) return;
      
      e.preventDefault();
      const targetId = anchor.getAttribute('href');
      if (!targetId || targetId === '#') return;
      
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        const top = (targetElement as HTMLElement).offsetTop - 80;
        window.scrollTo({
          top,
          behavior: 'smooth'
        });
      }
    };

    document.addEventListener('click', handleAnchorClick);
    return () => document.removeEventListener('click', handleAnchorClick);
  }, []);

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />

      {/* Hero Section */}
      <section className="pt-12 pb-24 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center">
            <div className="w-full md:w-1/2 md:pr-12">
              <h1 className="text-4xl sm:text-5xl font-nunito font-extrabold text-text leading-tight mb-6">
                Master English Speaking with <span className="text-primary">Skilladder AI</span>
              </h1>
              <p className="text-lg sm:text-xl font-opensans text-text opacity-80 mb-8">
                Get instant feedback on accent neutrality and CEFR proficiency levels. Improve your pronunciation and fluency with personalized insights.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Link href="/quiz" className="px-8 py-4 bg-primary hover:bg-[#3d8c40] text-white font-nunito font-bold text-lg rounded-full transition-colors text-center shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
                  Start Assessment
                </Link>
                <a href="#how-it-works" className="px-8 py-4 bg-white border-2 border-secondary text-secondary hover:bg-secondary hover:text-white font-nunito font-bold text-lg rounded-full transition-colors text-center shadow-sm hover:shadow-md">
                  Learn More
                </a>
              </div>
              <div className="mt-8 flex items-center space-x-4">
                <div className="flex -space-x-2">
                  <img src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100" alt="User testimonial" className="w-10 h-10 rounded-full border-2 border-white" />
                  <img src="https://images.unsplash.com/photo-1531384441138-2736e62e0919?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100" alt="User testimonial" className="w-10 h-10 rounded-full border-2 border-white" />
                  <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100" alt="User testimonial" className="w-10 h-10 rounded-full border-2 border-white" />
                </div>
                <div className="text-sm">
                  <p className="font-bold text-text">Join 25,000+ users</p>
                  <div className="flex text-accent">
                    <i className="ri-star-fill"></i>
                    <i className="ri-star-fill"></i>
                    <i className="ri-star-fill"></i>
                    <i className="ri-star-fill"></i>
                    <i className="ri-star-half-fill"></i>
                    <span className="ml-1 text-text">4.8/5</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="w-full md:w-1/2 mt-12 md:mt-0">
              <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-neutral">
                <div className="bg-primary px-6 py-4 flex items-center">
                  <i className="ri-mic-fill text-white text-xl mr-2"></i>
                  <h3 className="font-nunito font-bold text-white text-lg">Quick Assessment Demo</h3>
                </div>
                <div className="p-6 bg-white">
                  <div className="bg-neutral rounded-xl p-6 mb-6">
                    <p className="font-nunito font-bold mb-2">Please read this sentence aloud:</p>
                    <p className="text-lg font-opensans">"The quick brown fox jumps over the lazy dog."</p>
                  </div>
                  <div className="flex justify-center items-center mb-6">
                    <div className="audio-wave inactive">
                      {Array.from({ length: 8 }).map((_, i) => (
                        <div key={i} className="audio-wave-bar"></div>
                      ))}
                    </div>
                  </div>
                  <Link href="/quiz" className="w-full py-4 bg-secondary hover:bg-[#1976D2] text-white font-nunito font-bold rounded-full transition-colors flex items-center justify-center">
                    <i className="ri-mic-line mr-2 text-xl"></i>
                    Start Speaking
                  </Link>
                  <p className="text-center text-sm mt-4 text-text opacity-70">
                    Click the button and start speaking to see how it works
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16 px-4 sm:px-6 lg:px-8 bg-neutral">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-nunito font-bold text-text mb-4">Why Choose Skilladder AI</h2>
            <p className="text-lg font-opensans text-text opacity-70 max-w-2xl mx-auto">
              Our AI-powered platform provides detailed analysis of your English speaking skills with actionable feedback
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <i className="ri-robot-2-line text-2xl text-primary"></i>
              </div>
              <h3 className="font-nunito font-bold text-xl mb-2">AI-Powered Assessment</h3>
              <p className="font-opensans text-text opacity-80">
                Advanced AI technology evaluates your pronunciation, intonation, and fluency with human-like precision
              </p>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center mb-4">
                <i className="ri-file-chart-line text-2xl text-secondary"></i>
              </div>
              <h3 className="font-nunito font-bold text-xl mb-2">CEFR Proficiency Rating</h3>
              <p className="font-opensans text-text opacity-80">
                Get evaluated against international standards from beginner (A1) to mastery (C2) levels
              </p>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mb-4">
                <i className="ri-feedback-line text-2xl text-accent"></i>
              </div>
              <h3 className="font-nunito font-bold text-xl mb-2">Detailed Feedback</h3>
              <p className="font-opensans text-text opacity-80">
                Receive specific suggestions to improve pronunciation, grammar, vocabulary, and fluency
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
            <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                <i className="ri-sound-module-line text-2xl text-primary"></i>
              </div>
              <h3 className="font-nunito font-bold text-xl mb-2">Accent Neutrality Analysis</h3>
              <p className="font-opensans text-text opacity-80">
                Get insights on your accent characteristics and learn techniques to adjust for clearer communication
              </p>
            </div>
            
            <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center mb-4">
                <i className="ri-line-chart-line text-2xl text-secondary"></i>
              </div>
              <h3 className="font-nunito font-bold text-xl mb-2">Progress Tracking</h3>
              <p className="font-opensans text-text opacity-80">
                Monitor your improvement over time with comprehensive analytics and progress reports
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-nunito font-bold text-text mb-4">How It Works</h2>
            <p className="text-lg font-opensans text-text opacity-70 max-w-2xl mx-auto">
              Improve your English speaking skills in just three simple steps
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="relative">
              <div className="bg-neutral rounded-xl p-6 shadow-md">
                <span className="absolute -top-4 -left-4 w-12 h-12 bg-primary text-white font-nunito font-bold text-xl rounded-full flex items-center justify-center">1</span>
                <div className="pt-4">
                  <h3 className="font-nunito font-bold text-xl mb-4">Record Your Speech</h3>
                  <p className="font-opensans text-text opacity-80 mb-4">
                    Complete a short speaking task using our easy-to-use recording tool on any device
                  </p>
                  <div className="h-40 bg-white rounded-lg flex items-center justify-center">
                    <div className="flex flex-col items-center">
                      <i className="ri-mic-line text-5xl text-primary mb-2"></i>
                      <p className="text-sm text-text/70 font-opensans">Speak clearly into your microphone</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-neutral rounded-xl p-6 shadow-md">
                <span className="absolute -top-4 -left-4 w-12 h-12 bg-primary text-white font-nunito font-bold text-xl rounded-full flex items-center justify-center">2</span>
                <div className="pt-4">
                  <h3 className="font-nunito font-bold text-xl mb-4">AI Analysis</h3>
                  <p className="font-opensans text-text opacity-80 mb-4">
                    Our AI processes your speech sample to evaluate pronunciation, fluency, and overall proficiency
                  </p>
                  <div className="h-40 bg-white rounded-lg flex items-center justify-center">
                    <div className="flex flex-col items-center">
                      <div className="relative mb-2">
                        <i className="ri-brain-line text-5xl text-primary"></i>
                        <div className="absolute top-0 right-0 w-4 h-4 bg-secondary rounded-full animate-ping"></div>
                      </div>
                      <p className="text-sm text-text/70 font-opensans">Advanced AI analysis in progress</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-neutral rounded-xl p-6 shadow-md">
                <span className="absolute -top-4 -left-4 w-12 h-12 bg-primary text-white font-nunito font-bold text-xl rounded-full flex items-center justify-center">3</span>
                <div className="pt-4">
                  <h3 className="font-nunito font-bold text-xl mb-4">Get Detailed Results</h3>
                  <p className="font-opensans text-text opacity-80 mb-4">
                    Review your personalized assessment report with specific improvement suggestions
                  </p>
                  <div className="bg-white rounded-lg p-3 h-40">
                    <div className="flex justify-between mb-2">
                      <span className="font-nunito font-bold">Pronunciation</span>
                      <span className="text-primary font-bold">85%</span>
                    </div>
                    <div className="w-full bg-neutral/50 rounded-full h-2.5 mb-3">
                      <div className="bg-primary h-2.5 rounded-full" style={{ width: '85%' }}></div>
                    </div>
                    
                    <div className="flex justify-between mb-2">
                      <span className="font-nunito font-bold">Fluency</span>
                      <span className="text-secondary font-bold">72%</span>
                    </div>
                    <div className="w-full bg-neutral/50 rounded-full h-2.5 mb-3">
                      <div className="bg-secondary h-2.5 rounded-full" style={{ width: '72%' }}></div>
                    </div>
                    
                    <div className="flex justify-between mb-2">
                      <span className="font-nunito font-bold">Vocabulary</span>
                      <span className="text-accent font-bold">78%</span>
                    </div>
                    <div className="w-full bg-neutral/50 rounded-full h-2.5">
                      <div className="bg-accent h-2.5 rounded-full" style={{ width: '78%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Link href="/quiz" className="inline-block px-8 py-4 bg-primary hover:bg-[#3d8c40] text-white font-nunito font-bold text-lg rounded-full transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-0.5">
              Try It Now
            </Link>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-16 px-4 sm:px-6 lg:px-8 bg-neutral">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-nunito font-bold text-text mb-4">Simple Pricing</h2>
            <p className="text-lg font-opensans text-text opacity-70 max-w-2xl mx-auto">
              Choose the plan that fits your needs
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
              <div className="p-6 border-b border-neutral">
                <h3 className="font-nunito font-bold text-xl mb-2">Free</h3>
                <div className="flex items-end mb-4">
                  <span className="text-4xl font-nunito font-bold">$0</span>
                  <span className="text-text opacity-70 ml-1">/month</span>
                </div>
                <p className="font-opensans text-text opacity-80">
                  Perfect for trying out the platform
                </p>
              </div>
              <div className="p-6">
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <i className="ri-check-line text-primary mr-2"></i>
                    <span className="font-opensans">3 assessments per month</span>
                  </li>
                  <li className="flex items-center">
                    <i className="ri-check-line text-primary mr-2"></i>
                    <span className="font-opensans">Basic feedback</span>
                  </li>
                  <li className="flex items-center">
                    <i className="ri-check-line text-primary mr-2"></i>
                    <span className="font-opensans">CEFR level assessment</span>
                  </li>
                  <li className="flex items-center opacity-50">
                    <i className="ri-close-line text-[#F44336] mr-2"></i>
                    <span className="font-opensans">Detailed pronunciation feedback</span>
                  </li>
                  <li className="flex items-center opacity-50">
                    <i className="ri-close-line text-[#F44336] mr-2"></i>
                    <span className="font-opensans">Progress tracking</span>
                  </li>
                </ul>
                <Link href="/quiz" className="block w-full py-3 mt-6 bg-white border-2 border-primary text-primary hover:bg-primary hover:text-white font-nunito font-bold rounded-full transition-colors text-center">
                  Start Free
                </Link>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-lg overflow-hidden transform scale-105 border-2 border-primary relative">
              <div className="absolute top-0 right-0">
                <div className="bg-primary text-white py-1 px-4 rounded-bl-lg font-nunito font-bold text-sm">
                  Popular
                </div>
              </div>
              <div className="p-6 border-b border-neutral">
                <h3 className="font-nunito font-bold text-xl mb-2">Premium</h3>
                <div className="flex items-end mb-4">
                  <span className="text-4xl font-nunito font-bold">$9.99</span>
                  <span className="text-text opacity-70 ml-1">/month</span>
                </div>
                <p className="font-opensans text-text opacity-80">
                  Best for regular practice
                </p>
              </div>
              <div className="p-6">
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <i className="ri-check-line text-primary mr-2"></i>
                    <span className="font-opensans">Unlimited assessments</span>
                  </li>
                  <li className="flex items-center">
                    <i className="ri-check-line text-primary mr-2"></i>
                    <span className="font-opensans">Detailed feedback</span>
                  </li>
                  <li className="flex items-center">
                    <i className="ri-check-line text-primary mr-2"></i>
                    <span className="font-opensans">CEFR level assessment</span>
                  </li>
                  <li className="flex items-center">
                    <i className="ri-check-line text-primary mr-2"></i>
                    <span className="font-opensans">Detailed pronunciation feedback</span>
                  </li>
                  <li className="flex items-center">
                    <i className="ri-check-line text-primary mr-2"></i>
                    <span className="font-opensans">Progress tracking</span>
                  </li>
                </ul>
                <Link href="/quiz" className="block w-full py-3 mt-6 bg-primary hover:bg-[#3d8c40] text-white font-nunito font-bold rounded-full transition-colors text-center shadow-md hover:shadow-lg">
                  Get Started
                </Link>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
              <div className="p-6 border-b border-neutral">
                <h3 className="font-nunito font-bold text-xl mb-2">Enterprise</h3>
                <div className="flex items-end mb-4">
                  <span className="text-4xl font-nunito font-bold">$29.99</span>
                  <span className="text-text opacity-70 ml-1">/month</span>
                </div>
                <p className="font-opensans text-text opacity-80">
                  For teams and organizations
                </p>
              </div>
              <div className="p-6">
                <ul className="space-y-3">
                  <li className="flex items-center">
                    <i className="ri-check-line text-primary mr-2"></i>
                    <span className="font-opensans">Everything in Premium</span>
                  </li>
                  <li className="flex items-center">
                    <i className="ri-check-line text-primary mr-2"></i>
                    <span className="font-opensans">Team management</span>
                  </li>
                  <li className="flex items-center">
                    <i className="ri-check-line text-primary mr-2"></i>
                    <span className="font-opensans">Custom speaking tasks</span>
                  </li>
                  <li className="flex items-center">
                    <i className="ri-check-line text-primary mr-2"></i>
                    <span className="font-opensans">Analytics dashboard</span>
                  </li>
                  <li className="flex items-center">
                    <i className="ri-check-line text-primary mr-2"></i>
                    <span className="font-opensans">Priority support</span>
                  </li>
                </ul>
                <a href="#" className="block w-full py-3 mt-6 bg-white border-2 border-secondary text-secondary hover:bg-secondary hover:text-white font-nunito font-bold rounded-full transition-colors text-center">
                  Contact Sales
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-nunito font-bold text-text mb-4">What Our Users Say</h2>
            <p className="text-lg font-opensans text-text opacity-70 max-w-2xl mx-auto">
              Users from around the world are improving their English with SpeakSmart AI
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-neutral rounded-xl p-6 shadow-md">
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center">
                  <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&h=100" alt="User testimonial" className="w-12 h-12 rounded-full" />
                  <div className="ml-3">
                    <h4 className="font-nunito font-bold">Sophia Chen</h4>
                    <p className="text-sm opacity-70">Marketing Executive</p>
                  </div>
                </div>
                <div className="flex text-accent">
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                </div>
              </div>
              <p className="font-opensans text-text opacity-80">
                "SpeakSmart AI helped me improve my presentation skills dramatically. The accent feedback was eye-opening, and I now feel more confident during client meetings."
              </p>
            </div>
            
            <div className="bg-neutral rounded-xl p-6 shadow-md">
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center">
                  <img src="https://images.unsplash.com/photo-1531384441138-2736e62e0919?auto=format&fit=crop&w=100&h=100" alt="User testimonial" className="w-12 h-12 rounded-full" />
                  <div className="ml-3">
                    <h4 className="font-nunito font-bold">Rafael Santos</h4>
                    <p className="text-sm opacity-70">Software Engineer</p>
                  </div>
                </div>
                <div className="flex text-accent">
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-half-fill"></i>
                </div>
              </div>
              <p className="font-opensans text-text opacity-80">
                "As a non-native speaker working in tech, clear communication is essential. The specific pronunciation tips have been invaluable for my daily standup meetings."
              </p>
            </div>
            
            <div className="bg-neutral rounded-xl p-6 shadow-md">
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center">
                  <img src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=100&h=100" alt="User testimonial" className="w-12 h-12 rounded-full" />
                  <div className="ml-3">
                    <h4 className="font-nunito font-bold">Aisha Rahman</h4>
                    <p className="text-sm opacity-70">Graduate Student</p>
                  </div>
                </div>
                <div className="flex text-accent">
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                  <i className="ri-star-fill"></i>
                </div>
              </div>
              <p className="font-opensans text-text opacity-80">
                "Preparing for my university interviews was stressful, but practicing with Skilladder AI gave me the confidence I needed. I'm now studying at my dream school!"
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-primary">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="text-3xl font-nunito font-bold text-white mb-6">Ready to Transform Your English Speaking Skills?</h2>
          <p className="text-xl font-opensans text-white opacity-90 mb-8 max-w-2xl mx-auto">
            Join thousands of users worldwide who have improved their pronunciation and confidence with Skilladder AI
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link href="/quiz" className="px-8 py-4 bg-white text-primary hover:bg-neutral hover:text-[#3d8c40] font-nunito font-bold text-lg rounded-full transition-colors text-center shadow-lg hover:shadow-xl">
              Start Free Assessment
            </Link>
            <a href="#pricing" className="px-8 py-4 bg-[#3d8c40] hover:bg-[#3d8c40]/80 text-white font-nunito font-bold text-lg rounded-full transition-colors text-center border-2 border-white shadow-lg hover:shadow-xl">
              View Pricing
            </a>
          </div>
        </div>
      </section>

      <footer className="bg-[#333333] text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-1">
              <div className="flex items-center mb-4">
                <i className="ri-stack-line text-primary text-2xl mr-2"></i>
                <span className="font-nunito font-bold text-xl">Skilladder AI</span>
              </div>
              <p className="font-opensans text-white/70 mb-4">
                AI-powered English speaking assessment and improvement platform
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-white/70 hover:text-primary transition-colors">
                  <i className="ri-twitter-fill text-xl"></i>
                </a>
                <a href="#" className="text-white/70 hover:text-primary transition-colors">
                  <i className="ri-facebook-fill text-xl"></i>
                </a>
                <a href="#" className="text-white/70 hover:text-primary transition-colors">
                  <i className="ri-linkedin-fill text-xl"></i>
                </a>
                <a href="#" className="text-white/70 hover:text-primary transition-colors">
                  <i className="ri-instagram-fill text-xl"></i>
                </a>
              </div>
            </div>
            
            <div>
              <h3 className="font-nunito font-bold text-lg mb-4">Product</h3>
              <ul className="space-y-2">
                <li><a href="#features" className="font-opensans text-white/70 hover:text-primary transition-colors">Features</a></li>
                <li><a href="#pricing" className="font-opensans text-white/70 hover:text-primary transition-colors">Pricing</a></li>
                <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">For Teams</a></li>
                <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">For Education</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-nunito font-bold text-lg mb-4">Resources</h3>
              <ul className="space-y-2">
                <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">Blog</a></li>
                <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">Learning Center</a></li>
                <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">Pronunciation Guide</a></li>
                <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">CEFR Framework</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-nunito font-bold text-lg mb-4">Company</h3>
              <ul className="space-y-2">
                <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">About Us</a></li>
                <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">Careers</a></li>
                <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">Contact</a></li>
                <li><a href="#" className="font-opensans text-white/70 hover:text-primary transition-colors">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-white/20 mt-12 pt-6 flex flex-col md:flex-row justify-between items-center">
            <p className="font-opensans text-white/50 text-sm mb-4 md:mb-0">
              © {new Date().getFullYear()} Skilladder AI. All rights reserved.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="font-opensans text-white/50 hover:text-primary transition-colors text-sm">Terms of Service</a>
              <a href="#" className="font-opensans text-white/50 hover:text-primary transition-colors text-sm">Privacy Policy</a>
              <a href="#" className="font-opensans text-white/50 hover:text-primary transition-colors text-sm">Cookie Policy</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;
