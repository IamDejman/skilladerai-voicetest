import { useState, useEffect, useRef, useCallback } from "react";
import { Link, useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

// Define assessment stages
enum AssessmentType {
  TYPING_TEST = "typing",
  READING_COMPREHENSION = "reading",
  GRAMMAR = "grammar"
}

// Typing test text sample
const typingTestText = `Customer service is about helping people and solving problems with empathy and professionalism. When assisting customers, it's important to listen carefully, acknowledge their concerns, and provide clear solutions. Every interaction should aim to exceed expectations and leave a positive impression.`;

// Reading comprehension scenarios
const readingComprehensionScenarios = [
  {
    id: 1,
    scenario: `A customer calls in, clearly frustrated because they've been charged twice for their monthly subscription. They explain that they've already contacted their bank but were told to resolve it with your company directly. This is their third time calling about this issue.`,
    questions: [
      {
        id: "q1-1",
        question: "What would be the most appropriate initial response?",
        options: [
          "Tell them they need to be patient as these things take time to resolve.",
          "Apologize for the inconvenience and acknowledge their frustration.",
          "Explain that double charges happen sometimes and it's normal.",
          "Suggest they should have checked their account more carefully."
        ],
        correctAnswer: 1
      },
      {
        id: "q1-2",
        question: "What information would you need to gather first?",
        options: [
          "Their opinion about your company's billing system.",
          "How many times exactly they've called before.",
          "Their account details and the dates of the duplicate charges.",
          "Whether they've considered canceling their subscription."
        ],
        correctAnswer: 2
      }
    ]
  },
  {
    id: 2,
    scenario: `A customer emails your technical support team about an error they're experiencing with your software. They've attached several screenshots showing the error messages. The customer mentions they have an important presentation tomorrow and need this fixed urgently. You recognize that this is a known issue that requires several steps to resolve.`,
    questions: [
      {
        id: "q2-1",
        question: "What should be your first priority in this situation?",
        options: [
          "Explain that there's a queue and they'll have to wait their turn.",
          "Acknowledge the urgency and provide immediate next steps.",
          "Tell them to reschedule their presentation.",
          "Suggest they should have tested the software earlier."
        ],
        correctAnswer: 1
      },
      {
        id: "q2-2",
        question: "What tone would be most appropriate for your response?",
        options: [
          "Casual and friendly",
          "Technical and detailed",
          "Efficient but empathetic",
          "Brief and direct"
        ],
        correctAnswer: 2
      }
    ]
  }
];

// Grammar assessment questions
const grammarQuestions = [
  {
    id: "g1",
    question: "Select the sentence with correct grammar:",
    options: [
      "We was unable to locate you're account in our system.",
      "We were unable to locate your account in our system.",
      "We was unable to locate your account in our system.",
      "We were unable to locate you're account in our system."
    ],
    correctAnswer: 1
  },
  {
    id: "g2",
    question: "Fill in the blank: 'Please hold while I ________ your information.'",
    options: [
      "access",
      "excess",
      "acess",
      "axcess"
    ],
    correctAnswer: 0
  },
  {
    id: "g3",
    question: "Which sentence uses punctuation correctly?",
    options: [
      "Thank you for your patience I'll resolve this issue soon.",
      "Thank you for your patience, I'll resolve this issue soon.",
      "Thank you for your patience; I'll resolve this issue, soon.",
      "Thank you for your patience: I'll resolve this issue soon."
    ],
    correctAnswer: 1
  },
  {
    id: "g4",
    question: "Choose the correct word for the sentence: 'We value your ________ and are working to improve our service.'",
    options: [
      "feedback",
      "feedbach",
      "feedbak",
      "feedbeck"
    ],
    correctAnswer: 0
  },
  {
    id: "g5",
    question: "Identify the sentence with correct subject-verb agreement:",
    options: [
      "The customer have submitted multiple requests.",
      "The customer has submitted multiple requests.",
      "The customer having submitted multiple requests.",
      "The customer be submitting multiple requests."
    ],
    correctAnswer: 1
  }
];

const writingPrompt = `A customer has written to complain that a product they ordered arrived damaged. Write a brief response (approx. 50 words) acknowledging their concern and explaining the next steps they should take.`;

// Interface for typing metrics
interface TypingMetrics {
  wpm: number;
  accuracy: number;
  consistency: number;
  elapsedTime: number;
  keystrokes: number;
  correctChars: number;
  errorChars: number;
  totalChars: number;
}

// Interface for reading comprehension
interface ReadingAnswer {
  questionId: string;
  selectedOption: number;
}

// Interface for assessment results
interface AssessmentResults {
  typing?: {
    wpm: number;
    accuracy: number;
    consistency: number;
    passed: boolean;
  };
  reading?: {
    score: number;
    correctAnswers: number;
    totalQuestions: number;
    passed: boolean;
  };
  grammar?: {
    grammarScore: number;
    writingScore: number;
    overallPassed: boolean;
  };
  stage1Passed?: boolean;
}

const Assessment = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [assessmentType, setAssessmentType] = useState<AssessmentType>(AssessmentType.TYPING_TEST);
  const [isTestActive, setIsTestActive] = useState(false);
  const [isTestComplete, setIsTestComplete] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(180); // 3 minutes for typing test
  const [typedText, setTypedText] = useState("");
  const [typingMetrics, setTypingMetrics] = useState<TypingMetrics>({
    wpm: 0,
    accuracy: 0,
    consistency: 0,
    elapsedTime: 0,
    keystrokes: 0,
    correctChars: 0,
    errorChars: 0,
    totalChars: 0
  });
  const [currentReadingScenario, setCurrentReadingScenario] = useState(0);
  const [readingAnswers, setReadingAnswers] = useState<ReadingAnswer[]>([]);
  const [grammarAnswers, setGrammarAnswers] = useState<{ [key: string]: number }>({});
  const [writingResponse, setWritingResponse] = useState("");
  const [assessmentResults, setAssessmentResults] = useState<AssessmentResults>({});
  const [isProcessing, setIsProcessing] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const keystrokeTimesRef = useRef<number[]>([]);

  // Check if user has completed registration
  useEffect(() => {
    const candidateData = sessionStorage.getItem('candidateData');
    if (!candidateData) {
      toast({
        title: "Registration required",
        description: "Please complete the registration form before starting the assessment",
        variant: "destructive"
      });
      navigate('/quiz');
    }
  }, [navigate, toast]);

  // Handle timer for typing test
  useEffect(() => {
    if (isTestActive && assessmentType === AssessmentType.TYPING_TEST) {
      if (timeRemaining > 0) {
        timerRef.current = setTimeout(() => {
          setTimeRemaining(prev => prev - 1);
        }, 1000);
      } else {
        // Time's up
        completeTypingTest();
      }
    }

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [isTestActive, timeRemaining, assessmentType]);

  // Focus textarea when typing test starts
  useEffect(() => {
    if (isTestActive && assessmentType === AssessmentType.TYPING_TEST && textareaRef.current) {
      textareaRef.current.focus();
    }
  }, [isTestActive, assessmentType]);

  // Format time display
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  // Start typing test
  const startTypingTest = () => {
    setIsTestActive(true);
    setTypedText("");
    keystrokeTimesRef.current = [];
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  // Complete typing test and calculate metrics
  const completeTypingTest = useCallback(() => {
    setIsTestActive(false);
    setIsTestComplete(true);
    
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }
    
    // Calculate metrics
    const elapsedSeconds = 180 - timeRemaining;
    const totalChars = typedText.length;
    const originalTextSubset = typingTestText.substring(0, totalChars);
    
    let correctChars = 0;
    for (let i = 0; i < totalChars; i++) {
      if (i < typingTestText.length && typedText[i] === typingTestText[i]) {
        correctChars++;
      }
    }
    
    const errorChars = totalChars - correctChars;
    const accuracy = totalChars > 0 ? (correctChars / totalChars) * 100 : 0;
    
    // Words per minute (assuming average word length of 5 characters)
    const words = totalChars / 5;
    const minutes = elapsedSeconds / 60;
    const wpm = minutes > 0 ? words / minutes : 0;
    
    // Calculate typing consistency based on keystroke timing
    let consistency = 0;
    if (keystrokeTimesRef.current.length > 5) {
      const intervals = [];
      for (let i = 1; i < keystrokeTimesRef.current.length; i++) {
        intervals.push(keystrokeTimesRef.current[i] - keystrokeTimesRef.current[i-1]);
      }
      
      // Calculate standard deviation of intervals
      const mean = intervals.reduce((a, b) => a + b, 0) / intervals.length;
      const variance = intervals.map(x => Math.pow(x - mean, 2)).reduce((a, b) => a + b, 0) / intervals.length;
      const stdDev = Math.sqrt(variance);
      
      // Convert std dev to a consistency score (lower std dev = higher consistency)
      consistency = Math.max(0, 100 - Math.min(100, stdDev / 10));
    }
    
    const metrics: TypingMetrics = {
      wpm: Math.round(wpm),
      accuracy: Math.round(accuracy * 10) / 10,
      consistency: Math.round(consistency),
      elapsedTime: elapsedSeconds,
      keystrokes: totalChars,
      correctChars,
      errorChars,
      totalChars
    };
    
    setTypingMetrics(metrics);
    
    // Determine if passed (35 WPM with 85% accuracy required)
    const passed = metrics.wpm >= 35 && metrics.accuracy >= 85;
    
    setAssessmentResults(prev => ({
      ...prev,
      typing: {
        wpm: metrics.wpm,
        accuracy: metrics.accuracy,
        consistency: metrics.consistency,
        passed
      }
    }));
  }, [timeRemaining, typedText]);

  // Handle typing in the textarea
  const handleTyping = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (isTestActive) {
      setTypedText(e.target.value);
      keystrokeTimesRef.current.push(Date.now());
    }
  };

  // Handle manually completing the typing test
  const handleFinishTypingTest = () => {
    completeTypingTest();
  };

  // Handle reading comprehension answer selection
  const handleReadingAnswerSelect = (questionId: string, optionIndex: number) => {
    // Update reading answers
    const existingAnswerIndex = readingAnswers.findIndex(a => a.questionId === questionId);
    
    if (existingAnswerIndex >= 0) {
      const newAnswers = [...readingAnswers];
      newAnswers[existingAnswerIndex] = { questionId, selectedOption: optionIndex };
      setReadingAnswers(newAnswers);
    } else {
      setReadingAnswers([...readingAnswers, { questionId, selectedOption: optionIndex }]);
    }
  };

  // Complete reading comprehension test
  const completeReadingTest = () => {
    // Count correct answers
    let correctAnswers = 0;
    const totalQuestions = readingComprehensionScenarios.reduce(
      (total, scenario) => total + scenario.questions.length, 0
    );
    
    readingComprehensionScenarios.forEach(scenario => {
      scenario.questions.forEach(question => {
        const answer = readingAnswers.find(a => a.questionId === question.id);
        if (answer && answer.selectedOption === question.correctAnswer) {
          correctAnswers++;
        }
      });
    });
    
    const score = (correctAnswers / totalQuestions) * 100;
    const passed = score >= 70; // 70% required to pass
    
    setAssessmentResults(prev => ({
      ...prev,
      reading: {
        score,
        correctAnswers,
        totalQuestions,
        passed
      }
    }));
    
    setIsTestComplete(true);
  };

  // Handle grammar question answer
  const handleGrammarAnswerSelect = (questionId: string, optionIndex: number) => {
    setGrammarAnswers({
      ...grammarAnswers,
      [questionId]: optionIndex
    });
  };

  // Complete grammar assessment
  const completeGrammarTest = () => {
    // Count correct grammar answers
    let correctGrammarAnswers = 0;
    grammarQuestions.forEach(question => {
      if (grammarAnswers[question.id] === question.correctAnswer) {
        correctGrammarAnswers++;
      }
    });
    
    const grammarScore = (correctGrammarAnswers / grammarQuestions.length) * 100;
    
    // Evaluate writing response (simplified scoring)
    // In a real implementation, this would be more sophisticated
    const writingScore = Math.min(100, Math.max(0, (writingResponse.length / 50) * 100));
    
    // Combined score with 60% weight to grammar, 40% to writing
    const combinedScore = (grammarScore * 0.6) + (writingScore * 0.4);
    const passed = combinedScore >= 75; // 75% required to pass
    
    setAssessmentResults(prev => ({
      ...prev,
      grammar: {
        grammarScore,
        writingScore,
        overallPassed: passed
      }
    }));
    
    setIsTestComplete(true);
  };

  // Move to next assessment section
  const handleNextSection = () => {
    setIsTestComplete(false);
    
    if (assessmentType === AssessmentType.TYPING_TEST) {
      // Move to reading comprehension
      setAssessmentType(AssessmentType.READING_COMPREHENSION);
    } else if (assessmentType === AssessmentType.READING_COMPREHENSION) {
      // Move to grammar assessment
      setAssessmentType(AssessmentType.GRAMMAR);
    } else if (assessmentType === AssessmentType.GRAMMAR) {
      // Complete the assessment and process results
      processAssessmentResults();
    }
  };

  // Process full assessment results
  const processAssessmentResults = async () => {
    setIsProcessing(true);
    
    try {
      // Calculate if stage 1 is passed overall
      const typingPassed = assessmentResults.typing?.passed || false;
      const readingPassed = assessmentResults.reading?.passed || false;
      const grammarPassed = assessmentResults.grammar?.overallPassed || false;
      
      const stage1Passed = typingPassed && readingPassed && grammarPassed;
      
      const finalResults = {
        ...assessmentResults,
        stage1Passed
      };
      
      // In a real implementation, this would call an API
      // const response = await apiRequest('/api/stage1/results', {
      //   method: 'POST',
      //   body: JSON.stringify(finalResults)
      // });
      
      // For now, simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Store results and navigate to results page
      sessionStorage.setItem('stage1Results', JSON.stringify(finalResults));
      navigate('/results');
      
    } catch (error) {
      console.error("Error processing assessment results:", error);
      toast({
        title: "Assessment Error",
        description: "There was a problem processing your results. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Get selected answer for a reading question
  const getSelectedReadingAnswer = (questionId: string) => {
    const answer = readingAnswers.find(a => a.questionId === questionId);
    return answer ? answer.selectedOption : -1;
  };

  // Check if all questions in current scenario are answered
  const isCurrentScenarioComplete = () => {
    return readingComprehensionScenarios[currentReadingScenario].questions.every(q => 
      readingAnswers.some(a => a.questionId === q.id)
    );
  };

  // Check if all grammar questions are answered
  const areAllGrammarQuestionsAnswered = () => {
    return grammarQuestions.every(q => grammarAnswers[q.id] !== undefined);
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <main className="flex-1 py-8 px-4 sm:px-6 lg:px-8 bg-neutral">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-white shadow-lg overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-primary to-[#3d8c40] text-white">
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                <div>
                  <CardTitle className="text-2xl font-nunito font-bold">
                    Stage 1: Initial Screener
                  </CardTitle>
                  <CardDescription className="text-white/90 font-opensans">
                    Complete all three sections to qualify for the detailed assessment
                  </CardDescription>
                </div>
                <Tabs 
                  defaultValue={assessmentType} 
                  value={assessmentType}
                  className="w-full sm:w-auto"
                >
                  <TabsList className="bg-white/20 grid grid-cols-3 w-full sm:w-auto">
                    <TabsTrigger 
                      value={AssessmentType.TYPING_TEST}
                      disabled={assessmentType !== AssessmentType.TYPING_TEST && !isTestComplete}
                      className="text-sm py-1.5"
                    >
                      Typing
                    </TabsTrigger>
                    <TabsTrigger 
                      value={AssessmentType.READING_COMPREHENSION}
                      disabled={assessmentType !== AssessmentType.READING_COMPREHENSION && !isTestComplete}
                      className="text-sm py-1.5"
                    >
                      Reading
                    </TabsTrigger>
                    <TabsTrigger 
                      value={AssessmentType.GRAMMAR}
                      disabled={assessmentType !== AssessmentType.GRAMMAR && !isTestComplete}
                      className="text-sm py-1.5"
                    >
                      Grammar
                    </TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardHeader>
            
            <CardContent className="p-6">
              {isProcessing ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <div className="w-16 h-16 border-4 border-t-primary border-neutral rounded-full animate-spin mb-6"></div>
                  <h3 className="font-nunito font-bold text-xl mb-2">Processing Your Results</h3>
                  <p className="text-center text-text/70 font-opensans max-w-md">
                    We're calculating your overall assessment score and preparing your detailed feedback. This will only take a moment...
                  </p>
                </div>
              ) : (
                <>
                  {/* Typing Test Section */}
                  {assessmentType === AssessmentType.TYPING_TEST && (
                    <div className="space-y-6">
                      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 pb-4 border-b">
                        <div>
                          <h2 className="font-nunito font-bold text-xl">Typing Speed Test</h2>
                          <p className="text-text/70 font-opensans">
                            Type the text below as accurately and quickly as possible
                          </p>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-center">
                            <div className="text-2xl font-bold font-nunito">
                              {formatTime(timeRemaining)}
                            </div>
                            <div className="text-xs text-text/60">Time Remaining</div>
                          </div>
                          {isTestActive && (
                            <div className="text-center">
                              <div className="text-2xl font-bold font-nunito">
                                {typingMetrics.wpm}
                              </div>
                              <div className="text-xs text-text/60">WPM</div>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {!isTestActive && !isTestComplete ? (
                        <div className="space-y-6">
                          <div className="bg-neutral/30 p-4 rounded-lg">
                            <h3 className="font-nunito font-bold mb-2">Instructions</h3>
                            <ul className="list-disc pl-5 space-y-1 text-sm font-opensans text-text/80">
                              <li>You will have 3 minutes to type as much of the text as possible</li>
                              <li>Type at a comfortable pace that you could maintain during work</li>
                              <li>Focus on both speed and accuracy as both are important</li>
                              <li>The test will automatically end after 3 minutes</li>
                              <li>You need to achieve at least 35 WPM with 85% accuracy to pass</li>
                            </ul>
                          </div>
                          
                          <div className="bg-secondary/10 p-4 rounded-lg">
                            <h3 className="font-nunito font-bold mb-2">Sample Text Preview</h3>
                            <p className="text-sm font-opensans text-text/80">
                              {typingTestText.substring(0, 150)}...
                            </p>
                          </div>
                          
                          <div className="flex justify-center">
                            <Button 
                              onClick={startTypingTest}
                              className="bg-primary hover:bg-[#3d8c40] font-nunito font-bold py-5 px-8 text-lg"
                            >
                              Begin Typing Test
                            </Button>
                          </div>
                        </div>
                      ) : isTestActive ? (
                        <div className="space-y-6">
                          <div className="mb-2">
                            <div className="font-nunito font-semibold mb-2">Original Text:</div>
                            <div className="bg-neutral/20 p-4 rounded-lg text-sm font-opensans text-text/90">
                              {typingTestText}
                            </div>
                          </div>
                          
                          <div>
                            <div className="font-nunito font-semibold mb-2">Type Here:</div>
                            <textarea
                              ref={textareaRef}
                              value={typedText}
                              onChange={handleTyping}
                              className="w-full h-40 p-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary font-opensans text-sm"
                              placeholder="Start typing the text above..."
                              disabled={!isTestActive}
                            ></textarea>
                          </div>
                          
                          <div className="flex justify-end">
                            <Button 
                              onClick={handleFinishTypingTest}
                              variant="outline"
                              className="font-nunito"
                            >
                              Finish Early
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-6">
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            <div className="bg-white p-4 shadow-md rounded-lg text-center">
                              <div className="text-3xl font-bold font-nunito text-primary mb-1">
                                {typingMetrics.wpm}
                              </div>
                              <div className="text-sm font-opensans text-text/70">Words Per Minute</div>
                              <Badge className={`mt-2 ${typingMetrics.wpm >= 35 ? 'bg-green-500' : 'bg-red-500'}`}>
                                {typingMetrics.wpm >= 35 ? 'Passed' : 'Failed'} (35 WPM required)
                              </Badge>
                            </div>
                            
                            <div className="bg-white p-4 shadow-md rounded-lg text-center">
                              <div className="text-3xl font-bold font-nunito text-primary mb-1">
                                {typingMetrics.accuracy}%
                              </div>
                              <div className="text-sm font-opensans text-text/70">Accuracy</div>
                              <Badge className={`mt-2 ${typingMetrics.accuracy >= 85 ? 'bg-green-500' : 'bg-red-500'}`}>
                                {typingMetrics.accuracy >= 85 ? 'Passed' : 'Failed'} (85% required)
                              </Badge>
                            </div>
                            
                            <div className="bg-white p-4 shadow-md rounded-lg text-center">
                              <div className="text-3xl font-bold font-nunito text-primary mb-1">
                                {typingMetrics.consistency}%
                              </div>
                              <div className="text-sm font-opensans text-text/70">Consistency</div>
                              <div className="h-1.5 bg-gray-200 rounded-full mt-2">
                                <div 
                                  className="h-full bg-primary rounded-full" 
                                  style={{ width: `${typingMetrics.consistency}%` }}
                                ></div>
                              </div>
                            </div>
                          </div>
                          
                          <div className="bg-neutral/20 p-4 rounded-lg">
                            <h3 className="font-nunito font-bold mb-2">Detailed Metrics</h3>
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <span className="text-text/70">Total Time:</span> {typingMetrics.elapsedTime} seconds
                              </div>
                              <div>
                                <span className="text-text/70">Total Keystrokes:</span> {typingMetrics.keystrokes}
                              </div>
                              <div>
                                <span className="text-text/70">Correct Characters:</span> {typingMetrics.correctChars}
                              </div>
                              <div>
                                <span className="text-text/70">Error Characters:</span> {typingMetrics.errorChars}
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex justify-end">
                            <Button 
                              onClick={handleNextSection}
                              className="bg-primary hover:bg-[#3d8c40] font-nunito font-semibold"
                            >
                              Continue to Reading Comprehension
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {/* Reading Comprehension Section */}
                  {assessmentType === AssessmentType.READING_COMPREHENSION && (
                    <div className="space-y-6">
                      <div className="flex justify-between items-center pb-4 border-b">
                        <div>
                          <h2 className="font-nunito font-bold text-xl">Reading Comprehension</h2>
                          <p className="text-text/70 font-opensans">
                            Read each scenario and answer the multiple-choice questions
                          </p>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-semibold">
                            Scenario {currentReadingScenario + 1} of {readingComprehensionScenarios.length}
                          </div>
                        </div>
                      </div>
                      
                      {!isTestComplete ? (
                        <div className="space-y-6">
                          <div className="bg-neutral/20 p-5 rounded-lg">
                            <h3 className="font-nunito font-bold mb-3">Scenario</h3>
                            <p className="font-opensans text-text/90 mb-2">
                              {readingComprehensionScenarios[currentReadingScenario].scenario}
                            </p>
                          </div>
                          
                          <div className="space-y-8">
                            {readingComprehensionScenarios[currentReadingScenario].questions.map((question, questionIndex) => (
                              <div key={question.id} className="space-y-4">
                                <h4 className="font-nunito font-semibold">
                                  Question {questionIndex + 1}: {question.question}
                                </h4>
                                <div className="space-y-3">
                                  {question.options.map((option, optionIndex) => (
                                    <div 
                                      key={optionIndex}
                                      onClick={() => handleReadingAnswerSelect(question.id, optionIndex)}
                                      className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                                        getSelectedReadingAnswer(question.id) === optionIndex
                                          ? 'border-primary bg-primary/10'
                                          : 'border-gray-200 hover:border-gray-300'
                                      }`}
                                    >
                                      <div className="flex items-start">
                                        <div className={`w-5 h-5 rounded-full border flex-shrink-0 mr-3 ${
                                          getSelectedReadingAnswer(question.id) === optionIndex
                                            ? 'border-primary bg-primary text-white'
                                            : 'border-gray-300'
                                        }`}>
                                          {getSelectedReadingAnswer(question.id) === optionIndex && (
                                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-full h-full p-1">
                                              <polyline points="20 6 9 17 4 12"></polyline>
                                            </svg>
                                          )}
                                        </div>
                                        <span className="font-opensans text-text/80">{option}</span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                          
                          <div className="flex justify-between items-center pt-4">
                            <Button
                              variant="outline"
                              onClick={() => setCurrentReadingScenario(prev => Math.max(0, prev - 1))}
                              disabled={currentReadingScenario === 0}
                              className="font-nunito"
                            >
                              Previous Scenario
                            </Button>
                            
                            {currentReadingScenario < readingComprehensionScenarios.length - 1 ? (
                              <Button
                                onClick={() => setCurrentReadingScenario(prev => prev + 1)}
                                disabled={!isCurrentScenarioComplete()}
                                className="bg-primary hover:bg-[#3d8c40] font-nunito font-semibold"
                              >
                                Next Scenario
                              </Button>
                            ) : (
                              <Button
                                onClick={completeReadingTest}
                                disabled={!isCurrentScenarioComplete()}
                                className="bg-primary hover:bg-[#3d8c40] font-nunito font-semibold"
                              >
                                Complete Reading Assessment
                              </Button>
                            )}
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-6">
                          <div className="bg-white p-6 shadow-md rounded-lg text-center">
                            <div className="text-3xl font-bold font-nunito text-primary mb-2">
                              {Math.round(assessmentResults.reading?.score || 0)}%
                            </div>
                            <div className="font-opensans text-text/70 mb-4">Reading Comprehension Score</div>
                            <Progress value={assessmentResults.reading?.score || 0} className="h-2.5 mb-2" />
                            <Badge className={`${assessmentResults.reading?.passed ? 'bg-green-500' : 'bg-red-500'}`}>
                              {assessmentResults.reading?.passed ? 'Passed' : 'Failed'} (70% required)
                            </Badge>
                            
                            <div className="mt-4 text-sm text-text/70">
                              {assessmentResults.reading?.correctAnswers || 0} correct out of {assessmentResults.reading?.totalQuestions || 0} questions
                            </div>
                          </div>
                          
                          <div className="flex justify-end">
                            <Button 
                              onClick={handleNextSection}
                              className="bg-primary hover:bg-[#3d8c40] font-nunito font-semibold"
                            >
                              Continue to Grammar Assessment
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {/* Grammar Assessment Section */}
                  {assessmentType === AssessmentType.GRAMMAR && (
                    <div className="space-y-6">
                      <div className="pb-4 border-b">
                        <h2 className="font-nunito font-bold text-xl">Grammar & Writing Assessment</h2>
                        <p className="text-text/70 font-opensans">
                          Answer the grammar questions and complete a short writing task
                        </p>
                      </div>
                      
                      {!isTestComplete ? (
                        <div className="space-y-8">
                          <div>
                            <h3 className="font-nunito font-semibold text-lg mb-4">Grammar Questions</h3>
                            <div className="space-y-6">
                              {grammarQuestions.map((question, index) => (
                                <div key={question.id} className="space-y-3">
                                  <h4 className="font-nunito font-medium">
                                    Question {index + 1}: {question.question}
                                  </h4>
                                  <div className="space-y-2">
                                    {question.options.map((option, optionIndex) => (
                                      <div 
                                        key={optionIndex}
                                        onClick={() => handleGrammarAnswerSelect(question.id, optionIndex)}
                                        className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                                          grammarAnswers[question.id] === optionIndex
                                            ? 'border-primary bg-primary/10'
                                            : 'border-gray-200 hover:border-gray-300'
                                        }`}
                                      >
                                        <div className="flex items-start">
                                          <div className={`w-5 h-5 rounded-full border flex-shrink-0 mr-3 ${
                                            grammarAnswers[question.id] === optionIndex
                                              ? 'border-primary bg-primary text-white'
                                              : 'border-gray-300'
                                          }`}>
                                            {grammarAnswers[question.id] === optionIndex && (
                                              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-full h-full p-1">
                                                <polyline points="20 6 9 17 4 12"></polyline>
                                              </svg>
                                            )}
                                          </div>
                                          <span className="font-opensans text-text/80">{option}</span>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                          
                          <div className="pt-4 border-t">
                            <h3 className="font-nunito font-semibold text-lg mb-3">Writing Task</h3>
                            <p className="font-opensans text-text/80 mb-4">
                              {writingPrompt}
                            </p>
                            
                            <textarea
                              value={writingResponse}
                              onChange={(e) => setWritingResponse(e.target.value)}
                              className="w-full min-h-[150px] p-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary font-opensans text-sm"
                              placeholder="Type your response here..."
                            ></textarea>
                            
                            <div className="flex justify-between items-center mt-2">
                              <div className="text-sm text-text/60 font-opensans">
                                Approximately {writingResponse.split(/\s+/).filter(word => word.length > 0).length} words
                                (aim for ~50 words)
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex justify-end pt-4">
                            <Button
                              onClick={completeGrammarTest}
                              disabled={!areAllGrammarQuestionsAnswered() || writingResponse.length < 20}
                              className="bg-primary hover:bg-[#3d8c40] font-nunito font-semibold"
                            >
                              Complete Grammar Assessment
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-6">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div className="bg-white p-6 shadow-md rounded-lg text-center">
                              <div className="text-3xl font-bold font-nunito text-primary mb-2">
                                {Math.round(assessmentResults.grammar?.grammarScore || 0)}%
                              </div>
                              <div className="font-opensans text-text/70 mb-4">Grammar Score</div>
                              <Progress value={assessmentResults.grammar?.grammarScore || 0} className="h-2.5 mb-2" />
                            </div>
                            
                            <div className="bg-white p-6 shadow-md rounded-lg text-center">
                              <div className="text-3xl font-bold font-nunito text-primary mb-2">
                                {Math.round(assessmentResults.grammar?.writingScore || 0)}%
                              </div>
                              <div className="font-opensans text-text/70 mb-4">Writing Score</div>
                              <Progress value={assessmentResults.grammar?.writingScore || 0} className="h-2.5 mb-2" />
                            </div>
                          </div>
                          
                          <div className="bg-white p-6 shadow-md rounded-lg text-center">
                            <div className="text-xl font-bold font-nunito mb-2">
                              Overall Grammar & Writing Assessment
                            </div>
                            <Badge className={`${assessmentResults.grammar?.overallPassed ? 'bg-green-500' : 'bg-red-500'}`}>
                              {assessmentResults.grammar?.overallPassed ? 'Passed' : 'Failed'} (75% required)
                            </Badge>
                          </div>
                          
                          <div className="flex justify-end">
                            <Button 
                              onClick={handleNextSection}
                              className="bg-primary hover:bg-[#3d8c40] font-nunito font-semibold"
                            >
                              View Final Results
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </>
              )}
            </CardContent>
            
            <CardFooter className="bg-neutral/20 px-6 py-4">
              <div className="w-full flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="text-sm text-text/60 font-opensans">
                  Stage 1 Screener: Approximately 10 minutes to complete all sections
                </div>
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${assessmentType === AssessmentType.TYPING_TEST ? 'bg-primary' : (typingMetrics.wpm > 0 ? 'bg-green-500' : 'bg-gray-300')}`}></div>
                  <div className={`w-3 h-3 rounded-full ${assessmentType === AssessmentType.READING_COMPREHENSION ? 'bg-primary' : (assessmentResults.reading ? 'bg-green-500' : 'bg-gray-300')}`}></div>
                  <div className={`w-3 h-3 rounded-full ${assessmentType === AssessmentType.GRAMMAR ? 'bg-primary' : (assessmentResults.grammar ? 'bg-green-500' : 'bg-gray-300')}`}></div>
                </div>
              </div>
            </CardFooter>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Assessment;
