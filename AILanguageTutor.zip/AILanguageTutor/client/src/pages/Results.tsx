import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";

// Interface for Stage 1 assessment results
interface Stage1Results {
  typing?: {
    wpm: number;
    accuracy: number;
    consistency: number;
    passed: boolean;
  };
  reading?: {
    score: number;
    correctAnswers: number;
    totalQuestions: number;
    passed: boolean;
  };
  grammar?: {
    grammarScore: number;
    writingScore: number;
    overallPassed: boolean;
  };
  stage1Passed?: boolean;
}

// Sample stage 1 results for development only
const sampleStage1Results: Stage1Results = {
  typing: {
    wpm: 42,
    accuracy: 89.5,
    consistency: 78,
    passed: true
  },
  reading: {
    score: 75,
    correctAnswers: 3,
    totalQuestions: 4,
    passed: true
  },
  grammar: {
    grammarScore: 80,
    writingScore: 85,
    overallPassed: true
  },
  stage1Passed: true
};

const Results = () => {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [result, setResult] = useState<Stage1Results | null>(null);
  const [loading, setLoading] = useState(true);
  const [candidateInfo, setCandidateInfo] = useState<any>(null);

  useEffect(() => {
    // Check if user completed the assessment
    const candidateData = sessionStorage.getItem('candidateData');
    const stage1Results = sessionStorage.getItem('stage1Results');

    if (!candidateData) {
      toast({
        title: "Registration required",
        description: "Please complete the registration form first",
        variant: "destructive"
      });
      navigate('/quiz');
      return;
    }

    try {
      setCandidateInfo(JSON.parse(candidateData));
    } catch (e) {
      console.error("Error parsing candidate data:", e);
    }

    if (stage1Results) {
      try {
        setResult(JSON.parse(stage1Results));
      } catch (e) {
        console.error("Error parsing stage1 results:", e);
        setResult(null);
      }
    } else {
      // If we have no results, navigate back to assessment
      toast({
        title: "No assessment results",
        description: "Please complete the assessment to view your results",
        variant: "destructive"
      });
      navigate('/assessment');
      return;
    }
    
    setLoading(false);
  }, [navigate, toast]);

  // Helper function to get color based on pass/fail status
  const getStatusColor = (passed: boolean) => {
    return passed ? "bg-green-500" : "bg-red-500";
  };

  // Helper function to get text color based on score
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 70) return "text-green-500";
    if (score >= 60) return "text-yellow-500";
    return "text-red-500";
  };

  // Helper function to get background color for progress bar
  const getProgressColor = (score: number) => {
    if (score >= 80) return "bg-green-500";
    if (score >= 70) return "bg-green-400";
    if (score >= 60) return "bg-yellow-500";
    return "bg-red-500";
  };

  if (loading) {
    return (
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-1 py-16 px-4 sm:px-6 lg:px-8 bg-neutral flex items-center justify-center">
          <div className="w-16 h-16 border-4 border-t-primary border-neutral rounded-full animate-spin"></div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!result) {
    return (
      <div className="flex flex-col min-h-screen">
        <Navbar />
        <main className="flex-1 py-16 px-4 sm:px-6 lg:px-8 bg-neutral">
          <Card className="max-w-3xl mx-auto">
            <CardContent className="p-8 flex flex-col items-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
                <i className="ri-error-warning-line text-3xl text-[#F44336]"></i>
              </div>
              <h2 className="font-nunito font-bold text-2xl mb-2">No Assessment Results</h2>
              <p className="text-center text-text/70 mb-6">
                You haven't completed an assessment yet. Please complete the customer service assessment to see your results.
              </p>
              <Link href="/assessment">
                <Button className="bg-primary hover:bg-[#3d8c40] font-nunito font-bold">
                  Take Assessment
                </Button>
              </Link>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      
      <main className="flex-1 py-12 px-4 sm:px-6 lg:px-8 bg-neutral">
        <div className="max-w-4xl mx-auto">
          <Card className="mb-8 overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-primary to-[#3d8c40] text-white">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                  <CardTitle className="text-2xl font-nunito font-bold">Assessment Results</CardTitle>
                  <CardDescription className="text-white/90 font-opensans">
                    Stage 1: Initial Screener Summary
                  </CardDescription>
                </div>
                
                <Badge className={`${result.stage1Passed ? 'bg-green-500' : 'bg-red-500'} text-white px-4 py-1.5 text-sm font-medium rounded-full`}>
                  {result.stage1Passed ? 'PASSED' : 'NOT QUALIFIED'}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="p-6">
              {candidateInfo && (
                <div className="mb-6 pb-6 border-b border-gray-200">
                  <h3 className="font-nunito font-bold text-lg mb-3">Candidate Information</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Name</p>
                      <p className="font-medium">{candidateInfo.personalInfo.fullName}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Email</p>
                      <p className="font-medium">{candidateInfo.personalInfo.email}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 mb-1">Customer Service Experience</p>
                      <p className="font-medium">{candidateInfo.experience.customerServiceYears} years</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 mb-1">English Proficiency (Self-Assessed)</p>
                      <p className="font-medium">{candidateInfo.experience.englishProficiency}</p>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="mb-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-nunito font-bold text-lg">Assessment Components</h3>
                  <p className="text-sm text-gray-500">
                    Required: Pass all 3 components
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Typing Test Results Card */}
                  <Card className="shadow-sm border-2 overflow-hidden">
                    <CardHeader className={`py-3 px-4 ${result.typing?.passed ? 'bg-green-50 border-b-2 border-green-200' : 'bg-red-50 border-b-2 border-red-200'}`}>
                      <div className="flex justify-between items-center">
                        <h4 className="font-nunito font-bold text-base">Typing Test</h4>
                        <Badge className={getStatusColor(result.typing?.passed || false)}>
                          {result.typing?.passed ? 'Passed' : 'Failed'}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm text-gray-500">Speed</span>
                            <span className={`text-sm font-medium ${getScoreColor(result.typing?.wpm || 0)}`}>
                              {result.typing?.wpm} WPM
                            </span>
                          </div>
                          <Progress 
                            value={Math.min(100, ((result.typing?.wpm || 0) / 60) * 100)} 
                            className="h-1.5" 
                          />
                          <div className="flex justify-between mt-1">
                            <span className="text-xs text-gray-400">0</span>
                            <span className="text-xs text-gray-400">Min: 35</span>
                            <span className="text-xs text-gray-400">60+</span>
                          </div>
                        </div>
                        
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm text-gray-500">Accuracy</span>
                            <span className={`text-sm font-medium ${getScoreColor(result.typing?.accuracy || 0)}`}>
                              {result.typing?.accuracy}%
                            </span>
                          </div>
                          <Progress 
                            value={result.typing?.accuracy || 0} 
                            className="h-1.5" 
                          />
                          <div className="flex justify-between mt-1">
                            <span className="text-xs text-gray-400">0%</span>
                            <span className="text-xs text-gray-400">Min: 85%</span>
                            <span className="text-xs text-gray-400">100%</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Reading Comprehension Results Card */}
                  <Card className="shadow-sm border-2 overflow-hidden">
                    <CardHeader className={`py-3 px-4 ${result.reading?.passed ? 'bg-green-50 border-b-2 border-green-200' : 'bg-red-50 border-b-2 border-red-200'}`}>
                      <div className="flex justify-between items-center">
                        <h4 className="font-nunito font-bold text-base">Reading</h4>
                        <Badge className={getStatusColor(result.reading?.passed || false)}>
                          {result.reading?.passed ? 'Passed' : 'Failed'}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm text-gray-500">Score</span>
                            <span className={`text-sm font-medium ${getScoreColor(result.reading?.score || 0)}`}>
                              {Math.round(result.reading?.score || 0)}%
                            </span>
                          </div>
                          <Progress 
                            value={result.reading?.score || 0} 
                            className="h-1.5"
                          />
                          <div className="flex justify-between mt-1">
                            <span className="text-xs text-gray-400">0%</span>
                            <span className="text-xs text-gray-400">Min: 70%</span>
                            <span className="text-xs text-gray-400">100%</span>
                          </div>
                        </div>
                        
                        <div className="bg-gray-50 p-3 rounded-lg text-center">
                          <p className="text-sm font-medium">
                            {result.reading?.correctAnswers || 0} out of {result.reading?.totalQuestions || 0} correct
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Grammar & Writing Results Card */}
                  <Card className="shadow-sm border-2 overflow-hidden">
                    <CardHeader className={`py-3 px-4 ${result.grammar?.overallPassed ? 'bg-green-50 border-b-2 border-green-200' : 'bg-red-50 border-b-2 border-red-200'}`}>
                      <div className="flex justify-between items-center">
                        <h4 className="font-nunito font-bold text-base">Grammar & Writing</h4>
                        <Badge className={getStatusColor(result.grammar?.overallPassed || false)}>
                          {result.grammar?.overallPassed ? 'Passed' : 'Failed'}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm text-gray-500">Grammar</span>
                            <span className={`text-sm font-medium ${getScoreColor(result.grammar?.grammarScore || 0)}`}>
                              {Math.round(result.grammar?.grammarScore || 0)}%
                            </span>
                          </div>
                          <Progress 
                            value={result.grammar?.grammarScore || 0} 
                            className="h-1.5"
                          />
                        </div>
                        
                        <div>
                          <div className="flex justify-between mb-1">
                            <span className="text-sm text-gray-500">Writing</span>
                            <span className={`text-sm font-medium ${getScoreColor(result.grammar?.writingScore || 0)}`}>
                              {Math.round(result.grammar?.writingScore || 0)}%
                            </span>
                          </div>
                          <Progress 
                            value={result.grammar?.writingScore || 0} 
                            className="h-1.5"
                          />
                        </div>
                        
                        <div className="text-xs text-gray-500 text-center">
                          Combined score must be at least 75%
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
              
              {/* Overall Feedback Section */}
              <div className="mt-8 bg-gray-50 p-5 rounded-lg">
                <h3 className="font-nunito font-bold text-lg mb-3">Assessment Summary</h3>
                
                {result.stage1Passed ? (
                  <div className="space-y-4">
                    <div className="bg-green-50 border-l-4 border-green-500 p-4">
                      <div className="flex">
                        <div className="flex-shrink-0">
                          <svg className="h-5 w-5 text-green-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                          </svg>
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-green-800">
                            Congratulations! You've passed Stage 1 of our assessment process.
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <p className="text-gray-600">
                      You've successfully completed the initial screening process for our customer service position. Your results indicate that you have the necessary typing skills, reading comprehension, and written communication abilities required for this role.
                    </p>
                    
                    <div className="border-t border-gray-200 pt-4">
                      <h4 className="font-nunito font-semibold mb-2">Next Steps</h4>
                      <ol className="list-decimal list-inside space-y-1 text-gray-600">
                        <li>You will receive an email invitation for Stage 2 within 1-2 business days</li>
                        <li>Stage 2 will include a detailed assessment (25 minutes) focusing on voice analysis, situational judgment, and customer interaction simulation</li>
                        <li>Please ensure you have a working microphone and a quiet environment for Stage 2</li>
                      </ol>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="bg-red-50 border-l-4 border-red-500 p-4">
                      <div className="flex">
                        <div className="flex-shrink-0">
                          <svg className="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                          </svg>
                        </div>
                        <div className="ml-3">
                          <p className="text-sm font-medium text-red-800">
                            Unfortunately, you did not qualify for the next stage of our assessment process.
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <p className="text-gray-600">
                      Based on your results in the initial screening, we've determined that this position may not be the best match for your current skill set. We encourage you to continue developing your skills and apply again in the future.
                    </p>
                    
                    <div className="border-t border-gray-200 pt-4">
                      <h4 className="font-nunito font-semibold mb-2">Areas for Improvement</h4>
                      <ul className="list-disc list-inside space-y-1 text-gray-600">
                        {!result.typing?.passed && (
                          <li>
                            <span className="font-medium">Typing Speed and Accuracy:</span> Work on improving your typing skills to meet the minimum requirements of 35 WPM with 85% accuracy
                          </li>
                        )}
                        {!result.reading?.passed && (
                          <li>
                            <span className="font-medium">Reading Comprehension:</span> Practice understanding and interpreting customer service scenarios more effectively
                          </li>
                        )}
                        {!result.grammar?.overallPassed && (
                          <li>
                            <span className="font-medium">Written Communication:</span> Focus on grammar rules and professional writing skills for customer service contexts
                          </li>
                        )}
                      </ul>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
            
            <CardFooter className="bg-gray-50 p-6 flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/assessment">
                <Button 
                  variant="outline" 
                  className="w-full sm:w-auto font-nunito font-semibold"
                >
                  Retake Assessment
                </Button>
              </Link>
              
              <Button 
                className="w-full sm:w-auto bg-primary hover:bg-[#3d8c40] font-nunito font-semibold"
                onClick={() => window.print()}
              >
                <i className="ri-printer-line mr-2"></i>
                Print Results
              </Button>
              
              <Link href="/">
                <Button 
                  variant="secondary"
                  className="w-full sm:w-auto font-nunito font-semibold"
                >
                  Return to Home
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Results;
